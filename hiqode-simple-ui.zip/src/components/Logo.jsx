
import React from 'react'

export function Logo() {
  return (
    <div className="logo">
      <div className="dot" />
      <span>HiQode</span>
    </div>
  )
}
